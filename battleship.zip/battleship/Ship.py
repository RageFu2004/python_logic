class Ship:
    def __init__(self, name, length):
        self.name = name
        self.length = length