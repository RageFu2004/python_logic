class BattleMap:
    def __init__(self, height, width):
        self.height = height
        self.width = width
        self.map = []
        self.attackMap = []
        for i in range(height):
            self.map.append(["*"] * width)
            self.attackMap.append(["*"] * width)

    def attack(self, x, y, player, name_1, name_2):
        if player.map[x][y+1] != "*":
            print("{0} hits {1}'s {2}!".format(name_1, name_2, player.map[x][y+1]))
            hit_name = player.map[x][y+1]
            self.attackMap[x][y+1] = "X"
            player.map[x][y+1] = "X"
            return hit_name
        else:
            player.map[x][y+1] = "O"
            self.attackMap[x][y+1] = "O"
            print("{0} missed.".format(name_1))
            return 0

    def place_ship(self, ship, dir, x, y):
        if dir[0] == "V" or dir[0] == "v":
            for ise in range(int(ship.length)):
                if self.map[x+ise][y+1] != "*":
                    return False
            for ise in range(int(ship.length)):
                self.map[x + ise][y+1] = ship.name

        if dir[0] == "H" or dir[0] == "h":

            for j in range(int(ship.length)):
                if self.map[x][y+j+1] != "*":
                    return False
            for j in range(int(ship.length)):
                self.map[x][y + j+1] = ship.name

    def initialize(self):
        self.temp = [i for i in self.map]
        for index, j in enumerate(self.temp):
            j.insert(0, str(index))
        first_row = [str(i) for i in range(self.width)]
        first_row.insert(0, " ")
        self.temp.insert(0, first_row)

    def initialize_firing(self):
        self.temp_1 = [i for i in self.attackMap]
        for index, j in enumerate(self.temp_1):
            j.insert(0, str(index))
        first_row = [str(i) for i in range(self.width)]
        first_row.insert(0, " ")
        self.temp_1.insert(0, first_row)

    def show(self):
        for i in self.temp:
            for j in i:
                print(j, end=" ")
            print("\n")

    def show_firing(self):
        for i in self.temp_1:
            for j in i:
                print(j, end=" ")
            print("\n")

    def sunk(self, ship_name, player1, player2):
        for i in self.map:
            for j in i:
                if j == ship_name:
                    return False
        print("{0} destroyed {1}'s {2}!".format(player1, player2, ship_name))
        return True


