from battleship.Battle_ship import *
from battleship.Ship import *

if __name__ == "__main__":
    Doc = input("Please enter the path to the configuration file for this game: ")
    player1_name = input("Player 1, please enter your name: ")
    player2_name = input("Player 2, please enter your name: ")
    with open(Doc) as txtfile:
        a = txtfile.read()
    lst = a.split("\n")
    ship_lst = []
    for i in lst:
        if len(i) > 1:
            name, length = i.split()
            ship = Ship(name, int(length))
            ship_lst.append(ship)
    ship_lst.sort()
    while True:
        Ac = False
        height = lst[0]
        width = lst[1]
        for i in height:
            if i not in "1234567890":
                Ac = True
        for j in width:
            if j not in "1234567890":
                fuck = True
        if not Ac:
            break

    player1 = BattleMap(int(height), int(width))
    player1.initialize()
    player1.initialize_firing()

    print("{0}'s Placement Board".format(player1_name))
    player1.show()
    for i in ship_lst:
        while True:
            true_1 = True
            orientation = input("{0}, enter the orientation of your {1}, "
                                "which is {2} long: ".format(player1_name, i.name, i.length))
            if orientation[0] not in ['v', 'h', 'V', 'H']:
                true_1 = False
            if true_1:
                true_2 = True
                ins = input("{0} ,Enter the starting location for your {1}, which "
                            "is {2} long, in the form row col: ".format(player1_name, i.name, i.length))
                if " " not in ins:
                    true_2 = False
                if true_2:
                    true_3 = False
                    a1, a2 = ins.split()
                    if int(a1) >= 0 and int(a2) >= 0:
                        true_3 = False
                        if orientation[0] in ["v", "V"]:
                            if int(a1) + i.length <= player1.height:
                                true_3 = True
                        if orientation[0] in ["h", "H"]:
                            if int(a2) + i.length <= player1.width:
                                true_3 = True
                        if true_3:
                            if player1.place_ship(i, orientation, int(a1), int(a2)) is not False:
                                break
        print("{0}'s Placement Board".format(player1_name))
        player1.show()

    print("{0}'s Placement Board".format(player2_name))
    player2 = BattleMap(int(height), int(width))
    player2.initialize()
    player2.show()
    player2.initialize_firing()

    for i in ship_lst:
        while True:
            true_1 = True
            orientation = input("{0}, enter the orientation of your {1}, "
                                "which is {2} long: ".format(player2_name, i.name, i.length))
            if orientation[0] not in ['v', 'h', 'V', 'H']:
                true_1 = False
            if true_1:
                true_2 = True
                ins = input("{0} ,Enter the starting location for your {1}, which "
                        "is {2} long, in the form row col: ".format(player2_name, i.name, i.length))
                if " " not in ins:
                    true_2 = False
                if true_2:
                    a1, a2 = ins.split()
                    if int(a1) >= 0 and int(a2) >= 0:
                        true_3 = False
                        if orientation[0] in ["v", "V"]:
                            if int(a1) + i.length <= player2.height:
                                true_3 = True
                        if orientation[0] in ["h", "H"]:
                            if int(a2) + i.length <= player2.width:
                                true_3 = True
                        if true_3:
                            if player2.place_ship(i, orientation, int(a1), int(a2)) is not False:
                                break
        print("{0}'s Placement Board".format(player2_name))
        player2.show()
    while True:
        print("{0}'s Firing Board".format(player1_name))
        player1.show_firing()
        print("{0}'s Placement Board".format(player1_name))
        player1.show()
        while True:
            answer = input("{0}, enter the location you want to fire at in the form row col:".format(player1_name))
            if " " in answer:
                x, y = answer.split()
                if x in "0123456789" and y in "0123456789":
                    if int(x) < player1.height and int(y) < player1.width:
                        break
        Ship = player1.attack(int(x), int(y), player2, player1_name, player2_name)
        if Ship != 0:
            if player2.sunk(Ship, player1_name, player2_name):
                check = True
                for i in player2.map[1:]:
                    for j in i[1:]:
                        if j not in ["*", "O", "X"]:
                            check = False
                if check:
                    print("{0}'s Firing Board".format(player1_name))
                    player1.show_firing()
                    print("{0}'s Placement Board".format(player1_name))
                    player1.show()
                    print("{0} won!".format(player1_name))
                    break
        print("{0}'s Firing Board".format(player2_name))
        player2.show_firing()
        print("{0}'s Placement Board".format(player2_name))
        player2.show()
        while True:
            answer = input("{0}, enter the location you want to fire at in the form row col:".format(player2_name))
            if " " in answer:
                x, y = answer.split()
                if x in "0123456789" and y in "0123456789":
                    if int(x) < player2.height and int(y) < player2.width:
                        break
        Ship1 = player2.attack(int(x), int(y), player1, player2_name, player1_name)
        if Ship1 != 0:
            if player1.sunk(Ship, player2_name, player1_name):
                check = True
                for i in player1.map[1:]:
                    for j in i[1:]:
                        if j not in ["*", "O", "X"]:
                            check = False
                if check:
                    print("{0}'s Firing Board".format(player2_name))
                    player2.show_firing()
                    print("{0}'s Placement Board".format(player2_name))
                    player2.show()
                    print("{0} won!".format(player2_name))
                    break